#pragma once

namespace GUI::Controls {
	bool MultiDropdown( const std::string& name, std::vector< MultiItem_t > values);
}
