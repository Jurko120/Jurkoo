#pragma once

namespace GUI::Controls {
	void ColorPicker( const std::string& id, const std::string& value );
}
